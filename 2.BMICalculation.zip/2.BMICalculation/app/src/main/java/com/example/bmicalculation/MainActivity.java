package com.example.bmicalculation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    EditText h;
    EditText w;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        h = (EditText)findViewById(R.id.editTextTextPersonName);
        w = (EditText)findViewById(R.id.editTextTextPersonName2);
        final Button Calculation=(Button) findViewById(R.id.button);
        Calculation.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if ( !("".equals(h.getText().toString())
                        || "".equals(w.getText().toString())) )
                {
                    float fh = Float.parseFloat(h.getEditableText().toString());
                    float fw = Float.parseFloat(w.getEditableText().toString());

                    TextView result = (TextView)findViewById(R.id.textView7);
                    fh = fh/100;
                    fh = fh*fh;

                    NumberFormat nf = NumberFormat.getInstance();
                    nf.setMaximumFractionDigits(2);
                    result.setText(nf.format(fw/fh) +"");
                }
            }
        });
        final Button remove=(Button) findViewById(R.id.button2);
        remove.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                TextView result = (TextView)findViewById(R.id.textView7);
                result.setText("");
                EditText weight = (EditText)findViewById(R.id.editTextTextPersonName2);
                weight.setText("");
                EditText height = (EditText)findViewById(R.id.editTextTextPersonName);
                height.setText("");


            }
        });

    }
}